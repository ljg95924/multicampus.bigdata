import re

s_num, name, address, birth= '', '', '', ''
#r = re.compile("^[a-z][a-z0-9]{7,}$")
r = re.compile(r"^[가-힣]{1,5}$")  ##이름
while True:
    str = input("이름 입력 : ")
    if r.search(str) == None:
        print("잘못입력")
        continue
    else:
        name = str
        print(str)
        break

#r = re.compile("^[0-9]+$")  
r = re.compile(r"([1990-2017])(\d{2})(\d{3}$)")  ##학번
while True:
    str = input("학번입력 : ")
    if r.search(str) == None:
        print("잘못입력")
        continue
    else:
        s_num = str
        print(str)
        break

#r = re.compile("^[가-힣]+$")
str1="""
서울, 대전, 대구, 부산, 광주, 인천, 울산,
경북, 경남, 충북, 충남, 제주, 강원, 전북, 전남
"""
r = re.compile("^([가-힣]{2,20}$)") #주소
while True:
    str = input("주소입력 : ")
    if r.search(str) == None:
        print("잘못입력")
        continue
    else:
        address = str
        print(str)
        break

#r = re.compile("^[a-zA-Z]+$")
r = re.compile("^\d{6}$") # 생년월일
while True:
    str = input("생년월일 : ")
    if r.search(str) == None:
        print("잘못입력")
        continue
    else:
        birth = str
        print(str)
        break

f= open("morning.txt","w")  #파일 쓰기
f.write(name+","+s_num+","+address+","+birth)
f.close()

f = open("morning.txt","r") #파일 읽기
print(f.readlines())
